# Instructions  

Capture the user's search query.

    1. Add an event listener for 'keyup'
    2. Capture the event in a 'let' called 'searchQuery' and storing the value.
    3. Make sure the captured value is lowercase.
    4. Log to the console to demonstrate it works.